using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class LineFollow : MonoBehaviour
{
    public Transform targetA;
    public Transform targetB;
    private LineRenderer lineRenderer;

    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.positionCount = 2; // Устанавливаем количество точек
    }

    void Update()
    {
        if (targetA != null && targetB != null)
        {
            // Обновляем позиции точек в каждом кадре
            lineRenderer.SetPosition(0, targetA.position);
            lineRenderer.SetPosition(1, targetB.position);
        }
    }
}
